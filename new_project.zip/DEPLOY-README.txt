部署包日期：2026-11-02

运行环境：Node.js >=22.12.0
在解压目录执行：
  npm ci
  npm run build
  npm start

默认端口3000，可用PORT环境变量修改。
健康检查：/health；WebSocket：/ws。
HTTPS反向代理必须支持WebSocket Upgrade。
源码包不含node_modules、缓存及dist，启动前务必构建。构建需要Vite，请勿提前使用npm ci --omit=dev。
Docker部署：使用本包重新构建镜像并按原部署配置替换运行容器。
服务重启会中断内存中的联机房间，请避开正在进行的对局。
详细说明：docs/06-deployment.md。
校验：155项测试通过，Vite生产构建成功。
